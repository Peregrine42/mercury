curl 192.168.33.10/foobar
